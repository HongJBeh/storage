Members (CAPITALIZE)
1. LEE YI YUE
2. LIM HONG JUN
3. LOO YAN ZHEN
4. CHAN YIN ZHEN


Entry_point: MainPage.php

Login_info

Administrator
ID       :admin101	
Password :abcd1234

User
ID       :21PMD01221	
Password :tanahkau123


The login page cannot validate the admin nor member input as it have error yet unsolved.

The edit function in admin panel also cannot edit as it show that the field has been edited but it did not edit into the database.


edited:
(this read me is for my teacher see one just dont care, the log in function rosak one but the admin panel can function, many things in this are bootstrap so careful.)